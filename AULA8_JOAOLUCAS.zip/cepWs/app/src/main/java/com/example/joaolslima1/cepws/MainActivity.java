package com.example.joaolslima1.cepws;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    EditText cep;
    EditText logradouro;
    EditText complemento;
    EditText bairro;
    EditText localidade;
    EditText uf;
    EditText unidade;
    EditText ibge;
    EditText gia;

    Button buttonPesquisa;

    String txtCEP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cep = (EditText) findViewById(R.id.textCEP);
        logradouro = (EditText) findViewById(R.id.textLogradouro);
        complemento = (EditText) findViewById(R.id.textComplemento);
        bairro = (EditText) findViewById(R.id.textBairro);
        localidade = (EditText) findViewById(R.id.textLocalidade);
        uf = (EditText) findViewById(R.id.textUF);
        unidade = (EditText) findViewById(R.id.textUnidade);
        ibge = (EditText) findViewById(R.id.textIBGE);
        gia = (EditText) findViewById(R.id.textGia);

        buttonPesquisa = (Button) findViewById(R.id.buttonPesquisa);

        View.OnClickListener listener = new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {

                txtCEP = cep.getText().toString();

                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("http://viacep.com.br/ws/")
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();

                apiCEP apiCalculadora = retrofit.create(apiCEP.class);

                Call<crud> chamada = apiCalculadora.getCEP(txtCEP);

                Callback<crud> callbackCalculadora =
                        new Callback<crud>() {
                            @Override
                            public void onResponse(Call<crud> call, Response<crud> response) {

                                crud calc = response.body();

                                if (response.isSuccessful() && calc != null){

                                    logradouro.setText(String.valueOf(calc.getLogradouro()));
                                    complemento.setText(String.valueOf(calc.getComplemento()));
                                    bairro.setText(String.valueOf(calc.getBairro()));
                                    localidade.setText(String.valueOf(calc.getLocalidade()));
                                    uf.setText(String.valueOf(calc.getUf()));
                                    unidade.setText(String.valueOf(calc.getUnidade()));
                                    ibge.setText(String.valueOf(calc.getIbge()));
                                    gia.setText(String.valueOf(calc.getGia()));

                                }
                            }
                            @Override
                            public void onFailure(Call<crud> call, Throwable t) {
                                t.printStackTrace();
                                showDialog("Falha ao obter o resultado","Erro!!!");
                            }

                        };

                chamada.enqueue(callbackCalculadora);

            }
        };

        buttonPesquisa.setOnClickListener(listener);

    }

    private void showDialog(String val, String title) {
        AlertDialog.Builder builder = new
                AlertDialog.Builder(MainActivity.this);
        builder.setMessage(val);
        builder.setTitle(title);
        builder.setCancelable(false);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }



}
