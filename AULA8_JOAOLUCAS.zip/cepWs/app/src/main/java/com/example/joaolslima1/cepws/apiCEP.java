package com.example.joaolslima1.cepws;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface apiCEP {

    @GET("{cep}/json")
    Call<crud> getCEP (
            @Path("cep") String CEP);
}
