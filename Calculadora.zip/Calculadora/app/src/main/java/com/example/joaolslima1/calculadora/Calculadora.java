package com.example.joaolslima1.calculadora;

public class Calculadora {
    private Double soma;
    private Double sub;
    private Double mult;
    private Double div;


    public Double getSoma() {
        return soma;
    }

    public void setSoma(Double soma) {
        this.soma = soma;
    }

    public Double getSub() {
        return sub;
    }

    public void setSub(Double sub) {
        this.sub = sub;
    }

    public Double getMult() {
        return mult;
    }

    public void setMult(Double mult) {
        this.mult = mult;
    }

    public Double getDiv() {
        return div;
    }

    public void setDiv(Double div) {
        this.div = div;
    }
}
