package com.example.joaolslima1.calculadora;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiCalculadora {

    @GET("/getObject.php")
    Call<Calculadora> getObject (
            @Query("num1") Double num1,
            @Query("num2") Double num2);
}
