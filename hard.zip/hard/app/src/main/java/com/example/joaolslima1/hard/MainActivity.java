package com.example.joaolslima1.hard;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    Button btnFOTO;
    Button btnDIO;
    ImageView imagem;
    LocationManager locationManager;
    TextView txtLONG;
    TextView txtLATI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int permissionCheck = ContextCompat.checkSelfPermission(this,
            Manifest.permission.ACCESS_FINE_LOCATION);
            //caso nao tenhamos, pedir
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                int myrequest = 51;
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        myrequest);
        }

        txtLATI =  (TextView) findViewById(R.id.txtLATI);
        txtLONG =  (TextView) findViewById(R.id.txtLONG);
        btnDIO  = (Button) findViewById(R.id.btnDIO);
        btnFOTO = (Button) findViewById(R.id.btnFOTO);
        imagem = (ImageView) findViewById(R.id.imgFOTO);

        btnFOTO.setOnClickListener(
            //Define um listener de ação
            new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int REQUEST_IMAGE_CAPTURE = 51;
                    Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                    }
                }
            }
        );

        //obtem o gerenciador de localizaçã
        locationManager = (LocationManager) getSystemService(this.LOCATION_SERVICE);
        // Define um callback para lidar com as localizações alcançadas
        LocationListener locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                //usando a nova localizacao
                //Toast toast = Toast.makeText(MainActivity.this, "" + location.getLatitude() + " - " + location.getLongitude(), Toast.LENGTH_SHORT);
                txtLATI.setText(String.valueOf(location.getLatitude()));
                txtLONG.setText(String.valueOf(location.getLongitude()));
                //toast.show();
            }
            public void onStatusChanged(String provider, int status, Bundle extras) {}
            public void onProviderEnabled(String provider) {}
            public void onProviderDisabled(String provider) {}
        };

        // registra o callback
        int minTime = 0; //tempo minimo em milisegundos entre cada callback
        int minDistance = 0; //distancia minima em metros entre cada callback
        //usando o NETWORK_PROVIDER que busca da rede de celular e internet.
        //poderia ser o GPS_PROVIDER, que usa o GPS
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0,locationListener);

        btnDIO.setOnClickListener(
                //Define um listener de ação
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MediaPlayer mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.dio);
                        mediaPlayer.start();
                    }
                }
        );

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        int REQUEST_IMAGE_CAPTURE = 51;
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            imagem.setImageBitmap(imageBitmap);
        }
    }

    //implementar esse método na activity
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 51: {
        // Se a requisicao é cancelada, o vetor de resultado eh vazio
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

        // permissao concedida!
                } else {
        // permissao negada
                }
                return;
            }
        //pode conter outros resultados (cases) de outros pedidos de permissão
        }
    }





}
