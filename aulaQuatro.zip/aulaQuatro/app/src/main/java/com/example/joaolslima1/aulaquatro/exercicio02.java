package com.example.joaolslima1.aulaquatro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class exercicio02 extends AppCompatActivity {
    EditText nome;
    Button mudarTela;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio02);

        nome       = (EditText) findViewById(R.id.txtNOME);
        mudarTela  = (Button) findViewById(R.id.btnIRTELA);

        mudarTela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Implicito
                Intent intent = new Intent("ex02detalhe");
                intent.putExtra("nomeUsuario",nome.getText().toString());
                startActivity(intent);

            }
        });
    }
}
