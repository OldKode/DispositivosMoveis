package com.example.joaolslima1.aulaquatro;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class exercicio01 extends Activity {

    Button mudarTela;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mudarTela  = (Button) findViewById(R.id.btnIRTELA);

        mudarTela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent intent = new Intent(exercicio01.this, );
                //startActivity(intent);


                //Implicito
                Intent intent = new Intent("mimimi");
                startActivity(intent);

            }
        });
    }
}
