package com.example.joaolslima1.aulaquatro;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class exercicio03 extends AppCompatActivity {

    Button btnLINK;
    EditText txtLINK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio03);


        btnLINK = (Button) findViewById(R.id.btnLINK);
        txtLINK = (EditText) findViewById(R.id.txtURL);


        btnLINK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String link;
                link = txtLINK.getText().toString();
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                startActivity(i);

            }
        });
    }
}
