package com.example.joaolslima1.aulaquatro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class exercicio04detalhe extends AppCompatActivity {

    Button soma,subtrai,multiplica,divide;
    Double valor01,valor02;
    Intent returnIntent = new Intent();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio04detalhe);

        Intent volta = getIntent();


        valor01 = volta.getDoubleExtra("valor01",0);
        valor02 = volta.getDoubleExtra("valor02",0);

        soma = (Button) findViewById(R.id.btnSOMA);
        subtrai = (Button) findViewById(R.id.btnSUBTRAI);
        multiplica = (Button) findViewById(R.id.btnMULTIPLICA);
        divide = (Button) findViewById(R.id.btnDIVIDIR);
        
        soma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                returnIntent.putExtra("resultado",valor01 + valor02);
                setResult(RESULT_OK, returnIntent);
            }
        });

        subtrai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                returnIntent.putExtra("resultado",valor01 - valor02);
                setResult(RESULT_OK, returnIntent);
            }
        });

        multiplica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                returnIntent.putExtra("resultado",valor01 * valor02);
                setResult(RESULT_OK, returnIntent);
            }
        });

        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                returnIntent.putExtra("resultado",valor01 / valor02);
                setResult(RESULT_OK, returnIntent);
            }
        });


    }
}
