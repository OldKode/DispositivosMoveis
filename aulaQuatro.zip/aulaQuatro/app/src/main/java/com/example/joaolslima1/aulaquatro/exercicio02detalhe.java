package com.example.joaolslima1.aulaquatro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class exercicio02detalhe extends AppCompatActivity {
    TextView nomeShow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio02detalhe);

        nomeShow    = (TextView) findViewById(R.id.txtnomeUsuario);

        Intent intent = getIntent();

        String nome = intent.getStringExtra("nomeUsuario");
        nomeShow.setText("bem vindo " + nome);

    }

}
