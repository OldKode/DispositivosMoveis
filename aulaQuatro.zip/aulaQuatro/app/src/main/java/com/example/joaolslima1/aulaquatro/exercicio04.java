package com.example.joaolslima1.aulaquatro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class exercicio04 extends AppCompatActivity {

    EditText valor1,valor2,resultado;
    Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio04);

        valor1 = (EditText) findViewById(R.id.valor1);
        valor2 = (EditText) findViewById(R.id.valor2);
        resultado = (EditText) findViewById(R.id.resultado);

        btnCalcular = (Button) findViewById(R.id.btnCALCULAR);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent("ex04detalhe");
                i.putExtra("valor01", Double.parseDouble(valor1.getText().toString()));
                i.putExtra("valor02", Double.parseDouble(valor2.getText().toString()));
                startActivityForResult(i,1);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Verifica de quem veio a resposta
        if (requestCode == 1) {
            // Se foi resposta de sucesso
            if (resultCode == RESULT_OK) {
                // Faz alguma coisa
                resultado.setText(String.valueOf(data.getDoubleExtra("resultado",0)));
            }
        }
    }
}
