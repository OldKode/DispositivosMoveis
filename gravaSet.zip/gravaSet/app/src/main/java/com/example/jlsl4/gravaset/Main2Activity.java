package com.example.jlsl4.gravaset;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2Activity extends Activity {

    Button btnSALVAR;
    EditText txtNOME;
    EditText txtEMAIL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnSALVAR = (Button) findViewById(R.id.btnSALVAR);

        txtNOME = (EditText) findViewById(R.id.txtNOME);
        txtEMAIL= (EditText) findViewById(R.id.txtEMAIL);

        final bd sing = bd.getInstance();

        btnSALVAR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sing.setNome(txtNOME.getText().toString());
                sing.setEmail(txtEMAIL.getText().toString());

                Intent terceira = new Intent("terceira");
                startActivity(terceira);
            }
        });
    }
}
