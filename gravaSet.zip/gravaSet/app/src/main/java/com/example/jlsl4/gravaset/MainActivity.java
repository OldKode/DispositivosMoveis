package com.example.jlsl4.gravaset;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btACEITO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final SharedPreferences prefs = getSharedPreferences("MinhaConfig",MODE_PRIVATE);
        Integer config = prefs.getInt("aceitou",0);

        if (config == 1)
            abreSegundaTela();

        btACEITO = (Button) findViewById(R.id.btACEITO);

        btACEITO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putInt("aceitou",1);
                editor.apply();
                abreSegundaTela();
            }
        });

    }

    void abreSegundaTela(){
        Intent segunda = new Intent("segunda");
        startActivity(segunda);
    }

}
