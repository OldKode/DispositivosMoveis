package com.example.jlsl4.gravaset;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;

public class Main3Activity extends Activity {

    EditText txtNOME;
    EditText txtEMAIL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        txtNOME = (EditText) findViewById(R.id.txtNOME);
        txtEMAIL= (EditText) findViewById(R.id.txtEMAIL);

        final bd sing = bd.getInstance();

        txtNOME.setText(sing.getNome());
        txtEMAIL.setText(sing.getEmail());
    }
}
