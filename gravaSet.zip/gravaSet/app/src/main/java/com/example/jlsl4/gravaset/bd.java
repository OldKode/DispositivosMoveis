package com.example.jlsl4.gravaset;

public class bd {
    private static final bd ourInstance = new bd();

    private String  nome ;
    private String email;
    public static bd getInstance() {
        return ourInstance;
    }

    private bd() {

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
