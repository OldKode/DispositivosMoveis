package com.example.joaolslima1.materialptdois;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentoUm extends Fragment {

    private EditText nome;
    private EditText dtNasc;
    private EditText genero;
    private EditText estCivil;


    public FragmentoUm() {
        // Required empty public constructor

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //Carrega o layout do fragmento
        View view = inflater.inflate(
                R.layout.fragment_fragmento_um, container, false);
        nome     = (EditText) view.findViewById(R.id.etNOME);
        dtNasc   = (EditText) view.findViewById(R.id.etNASC);
        genero   = (EditText) view.findViewById(R.id.etGENERO);
        estCivil = (EditText) view.findViewById(R.id.etESTCIVIL);
        return view;

    }

    public void salvaValores(){
        //preenche campos no banco
        FakeBD.nome                 = nome.getText().toString();
        FakeBD.data_de_nascimento   = dtNasc.getText().toString();
        FakeBD.genero               = genero.getText().toString();
        FakeBD.estado_civil         = estCivil.getText().toString();

        //Limpa Campos
        nome.setText("");
        dtNasc.setText("");
        genero.setText("");
        estCivil.setText("");
    }
}
