package com.example.joaolslima1.materialptdois;

public class FakeBD {

    //Cadastro básico
    public static String nome;
    public static String data_de_nascimento;
    public static String genero;
    public static String estado_civil;

    //Cadastro de endereço
    public static String rua;
    public static String numero;
    public static String bairro;
    public static String cidade;
    public static String estado;
}
