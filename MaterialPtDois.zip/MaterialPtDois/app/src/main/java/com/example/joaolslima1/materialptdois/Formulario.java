package com.example.joaolslima1.materialptdois;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class Formulario extends AppCompatActivity {

    //Cadastro básico
    private EditText nome;
    private EditText dtNasc;
    private EditText genero;
    private EditText estCivil;

    //Cadastro Endereço
    private EditText rua;
    private EditText numero;
    private EditText bairro;
    private EditText cidade;
    private EditText estado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        //Bind de inf Basica
        nome = (EditText) findViewById(R.id.etNOME);
        dtNasc = (EditText) findViewById(R.id.etNASC);
        genero = (EditText) findViewById(R.id.etGENERO);
        estCivil = (EditText) findViewById(R.id.etESTCIVIL);

        //Bind de Endereços
        rua = (EditText) findViewById(R.id.etRUA);
        numero = (EditText) findViewById(R.id.etNUMERO);
        bairro = (EditText) findViewById(R.id.etBAIRRO);
        cidade = (EditText) findViewById(R.id.etCIDADE);
        estado = (EditText) findViewById(R.id.etESTADO);

        //Preenche Basico
        nome.setText(FakeBD.nome);
        dtNasc.setText(FakeBD.data_de_nascimento);
        genero.setText(FakeBD.genero);
        estCivil.setText(FakeBD.estado_civil);

        //Preenche Endereço
        rua.setText(FakeBD.rua);
        numero.setText(FakeBD.numero);
        bairro.setText(FakeBD.bairro);
        cidade.setText(FakeBD.cidade);
        estado.setText(FakeBD.estado);
    }
}
