package com.example.joaolslima1.materialptdois;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private Fragment fragAux;
    private ViewPager pager;
    private TabLayout TabLayout;
    private FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pager     = (ViewPager) findViewById(R.id.pager);
        TabLayout = (TabLayout) findViewById(R.id.tabslayout);
        fab       = (FloatingActionButton) findViewById(R.id.fabEdit);

        final SectionsPagerAdapter adapter = new SectionsPagerAdapter(getSupportFragmentManager());

        pager.setAdapter(adapter);
        TabLayout.setupWithViewPager(pager);
        TabLayout.setSelectedTabIndicatorHeight(16);

        fab.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                FragmentoUm f1 =  (FragmentoUm) adapter.getItem(0);
                f1.salvaValores();
                FragmentoDois f2 =  (FragmentoDois) adapter.getItem(1);
                f2.salvaValores();
                Snackbar.make(v,"Valores adicionados!!!",Snackbar.LENGTH_SHORT)
                        .setAction("Ação!", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                abreForm();
                            }
                        }).show();

            }
        });
    }

    public void abreForm(){
        Intent intent = new Intent(this, Formulario.class );
        startActivity(intent);
    }
}
