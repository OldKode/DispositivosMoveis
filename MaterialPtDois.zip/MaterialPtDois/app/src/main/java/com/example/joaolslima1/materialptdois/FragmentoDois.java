package com.example.joaolslima1.materialptdois;


import android.os.Bundle;
import android.support.v4.app.Fragment;;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentoDois extends Fragment {

    private EditText rua;
    private EditText numero;
    private EditText bairro;
    private EditText cidade;
    private EditText estado;

    public FragmentoDois() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //Carrega o layout do fragmento
        View view = inflater.inflate(
                R.layout.fragment_fragmento_dois, container, false);
        rua     = (EditText) view.findViewById(R.id.etRUA);
        numero  = (EditText) view.findViewById(R.id.etNUMERO);
        bairro  = (EditText) view.findViewById(R.id.etBAIRRO);
        cidade  = (EditText) view.findViewById(R.id.etCIDADE);
        estado  = (EditText) view.findViewById(R.id.etESTADO);
        return view;
    }


    public void salvaValores(){
        //preenche campos no banco
        FakeBD.rua      = rua.getText().toString();
        FakeBD.numero   = numero.getText().toString();
        FakeBD.bairro   = bairro.getText().toString();
        FakeBD.cidade   = cidade.getText().toString();
        FakeBD.estado   = estado.getText().toString();

        //Limpa campos
        rua.setText("");
        numero.setText("");
        bairro.setText("");
        cidade.setText("");
        estado.setText("");
    }
}
