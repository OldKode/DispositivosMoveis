package com.example.joaolslima1.myapplication;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText nome;
    Button botao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome = (EditText) findViewById(R.id.etNome);
        botao = (Button) findViewById(R.id.btnSaudar);



        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome_compara = "jooj";
                if (nome_compara.equals(nome.getText().toString())) {
                    showDialog("Olá " + nome.getText().toString(), "Boas Vindas");
                }else{
                    showDialog("Falha ao conectar","Erro!!!");
                };
            }
        };

        botao.setOnClickListener(listener);
    }


    private void showDialog(String message, String title) {
        //Declara e instancia uma fábrica de construção de diálogos

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        //Configura o corpo da mensagem
        builder.setMessage(message);
        //Configura o título da mensagem
        builder.setTitle(title);
        //Impede que o botão seja cancelável (possa clicar
        //em voltar ou fora para fechar)
        builder.setCancelable(false);
        //Configura um botão de OK para fechamento (um
        //outro listener pode ser configurado no lugar do "null")
        builder.setPositiveButton("OK", null);
        //Cria efetivamente o diálogo
        AlertDialog dialog = builder.create();
        //Faz com que o diálogo apareça na tela
        dialog.show();
    }

}
