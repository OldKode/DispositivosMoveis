package com.example.joaolslima1.dinam;

public class crud {
    private String precProduto;
    private String idCategoria;
    private String descProduto;
    private String nomeProduto;
    private String ativoProduto;
    private String qtdMinEstoque;
    private String idProduto;
    private String descontoPromocao;

    public String getPrecProduto() {
        return precProduto;
    }

    public void setPrecProduto(String precProduto) {
        this.precProduto = precProduto;
    }

    public String getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(String idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getDescProduto() {
        return descProduto;
    }

    public void setDescProduto(String descProduto) {
        this.descProduto = descProduto;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public String getAtivoProduto() {
        return ativoProduto;
    }

    public void setAtivoProduto(String ativoProduto) {
        this.ativoProduto = ativoProduto;
    }

    public String getQtdMinEstoque() {
        return qtdMinEstoque;
    }

    public void setQtdMinEstoque(String qtdMinEstoque) {
        this.qtdMinEstoque = qtdMinEstoque;
    }

    public String getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(String idProduto) {
        this.idProduto = idProduto;
    }

    public String getDescontoPromocao() {
        return descontoPromocao;
    }

    public void setDescontoPromocao(String descontoPromocao) {
        this.descontoPromocao = descontoPromocao;
    }
}
