package com.example.joaolslima1.dinam;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface apiConsome {

    @GET("{prodID}")
    Call<crud> getPROD (
            @Path("prodID") String idProduto);
}
