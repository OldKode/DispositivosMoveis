package com.example.joaolslima1.dinam;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends Activity {
    private ViewGroup mensagens;
    String idProd;
    int qtdProduto = 10 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mensagens = (ViewGroup) findViewById(R.id.container);


        for(int ind = 1; ind < qtdProduto+1; ind++){
            addItem(ind);
        }

    }

    private void addItem(int idProduto) {
        idProd = String.valueOf(idProduto);

        //Inicia a conexão com a internet
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://oficinacordova.azurewebsites.net/android/rest/produto/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        apiConsome apiCons = retrofit.create(apiConsome.class);

        Call<crud> chamada = apiCons.getPROD(idProd);

        Callback<crud> callbackProduto =
            new Callback<crud>() {
                @Override
                public void onResponse(Call<crud> call, Response<crud> response) {

                    crud ret = response.body();


                    if (response.isSuccessful() && ret != null){
                        //logradouro.setText(String.valueOf( ret.getLogradouro()));

                        //Parte de imagem
                        CardView cardView = (CardView) LayoutInflater.from(MainActivity.this)
                                .inflate(R.layout.card, mensagens, false);
                        TextView titulo = (TextView) cardView.findViewById(R.id.titulo);
                        TextView mensagem = (TextView) cardView.findViewById(R.id.mensagem);
                        TextView preco = (TextView) cardView.findViewById(R.id.preco);
                        TextView desconto = (TextView) cardView.findViewById(R.id.desconto);


                        titulo.setText(ret.getNomeProduto());
                        mensagem.setText("Descrição: " + ret.getDescProduto());
                        preco.setText("Preço: R$" + ret.getPrecProduto());
                        desconto.setText("Desconto: R$" + ret.getDescontoPromocao());

                        ImageView imagem = (ImageView) cardView.findViewById(R.id.imageView);
                        String url = "https://oficinacordova.azurewebsites.net/android/rest/produto/image/" + ret.getIdProduto();
                        ImageLoader imageLoader = ImageLoader.getInstance();
                        imageLoader.init(ImageLoaderConfiguration.createDefault(MainActivity.this));
                        imageLoader.displayImage(url, imagem);


                        //Cria card
                        mensagens.addView(cardView);
                    }
                }
                @Override
                public void onFailure(Call<crud> call, Throwable t) {
                    t.printStackTrace();
                    showDialog("Falha ao obter o resultado","Erro!!!");
                }

            };

        chamada.enqueue(callbackProduto);
    }

    private void showDialog(String val, String title) {
        AlertDialog.Builder builder = new
                AlertDialog.Builder(MainActivity.this);
        builder.setMessage(val);
        builder.setTitle(title);
        builder.setCancelable(false);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
