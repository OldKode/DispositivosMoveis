package com.example.joaolslima1.calculadora;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CalculadoraActivity extends AppCompatActivity {

    EditText cep;
    EditText logradouro;
    EditText complemento;
    EditText bairro;
    EditText localidade;
    EditText uf;
    EditText unidade;
    EditText ibge;
    EditText gia;

    Button buttonPesquisa;

    String txtCEP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        cep = (EditText) findViewById(R.id.textCEP);
        logradouro = (EditText) findViewById(R.id.textLogradouro);
        complemento = (EditText) findViewById(R.id.textComplemento);
        bairro = (EditText) findViewById(R.id.textBairro);
        localidade = (EditText) findViewById(R.id.textLocalidade);
        uf = (EditText) findViewById(R.id.textUF);
        unidade = (EditText) findViewById(R.id.textUnidade);
        ibge = (EditText) findViewById(R.id.textIBGE);
        gia = (EditText) findViewById(R.id.textGia);


        View.OnClickListener listener = new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                /*
                Double val1 = null;
                Double val2 = null;

                try {
                    val1 = Double.parseDouble(textVal1.getText().toString());
                    num1 =  val1;
                }
                catch(Exception e) {
                    e.printStackTrace();
                    showDialog("Valor 1 inválido", "Erro");
                    return;
                }

                try {
                    val2 = Double.parseDouble(textVal2.getText().toString());
                    num2 =  val2;
                }
                catch(Exception e) {
                    e.printStackTrace();
                    showDialog("Valor 2 inválido", "Erro");
                    return;
                }


                if (!radioSoma.isChecked() && !radioSub.isChecked()
                        && !radioMult.isChecked() && !radioDiv.isChecked()) {
                    showDialog("Selecione uma operação", "Erro");
                    return;
                }
                */
                txtCEP = cep.getText().toString();

                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("http://http://viacep.com.br/")
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();

                ApiCalculadora apiCalculadora = retrofit.create(ApiCalculadora.class);

                Call<Calculadora> chamada = apiCalculadora.getCEP(txtCEP);

                Callback<Calculadora> callbackCalculadora =
                        new Callback<Calculadora>() {
                            @Override
                            public void onResponse(Call<Calculadora> call, Response<Calculadora> response) {

                                Calculadora calc = response.body();

                                if (response.isSuccessful() && calc != null){

                                    logradouro.setText(String.valueOf(calc.getLogradouro()));
                                    complemento.setText(String.valueOf(calc.getComplemento()));
                                    bairro.setText(String.valueOf(calc.getBairro()));
                                    localidade.setText(String.valueOf(calc.getLocalidade()));
                                    uf.setText(String.valueOf(calc.getUf()));
                                    unidade.setText(String.valueOf(calc.getUnidade()));
                                    ibge.setText(String.valueOf(calc.getIbge()));
                                    gia.setText(String.valueOf(calc.getGia()));

                                }
                            }
                            @Override
                            public void onFailure(Call<Calculadora> call, Throwable t) {
                                t.printStackTrace();
                                showDialog("Falha ao obter o resultado","Erro!!!");
                            }

                        };

                chamada.enqueue(callbackCalculadora);

            }
        };

        buttonPesquisa.setOnClickListener(listener);

    }

    private void showDialog(String val, String title) {
        AlertDialog.Builder builder = new
                AlertDialog.Builder(CalculadoraActivity.this);
        builder.setMessage(val);
        builder.setTitle(title);
        builder.setCancelable(false);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }



}
