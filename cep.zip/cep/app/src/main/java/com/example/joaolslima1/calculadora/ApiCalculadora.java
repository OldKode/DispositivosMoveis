package com.example.joaolslima1.calculadora;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiCalculadora {

    @GET("/ws/{cep}/json")
    Call<Calculadora> getCEP (
            @Path("cep") String CEP);
}
